﻿Imports System
Imports System.Windows.Forms

Public Module Program

    <STAThread>
    Public Sub Main()
        Application.SetHighDpiMode(HighDpiMode.SystemAware)
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        ' Sign in (or create an account) first. Closing the window quits; "Continue without an account" skips.
        If Not AuthFlow.Run() Then Return

        Application.Run(New MainForm())
    End Sub

End Module
